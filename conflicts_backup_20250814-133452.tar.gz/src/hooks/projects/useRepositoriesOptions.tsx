import { useEffect, useState } from "react";
import { getRepositories } from "../../services/projects/projectService";

export const useRepositoriesOptions = () => {
  const [options, setOptions] = useState<{ value: string; label: string }[]>([]);

  useEffect(() => {
    getRepositories().then(data => {
<<<<<<< HEAD
      const mapped = data.map((r: any) => ({
        value: r.id.toString(),
        label: r.name,
      }));
      setOptions(mapped);
=======
      if (data && Array.isArray(data)) {
        const mapped = data.map((r: any) => ({
          value: r.id.toString(),
          label: r.name,
        }));
        setOptions(mapped);
      }
    }).catch(() => {
      // Si falla, mantener array vacío
      setOptions([]);
>>>>>>> permisos-y-resposive
    });
  }, []);

  return options;
};