// src/components/user/index.ts
// 👥 EXPORTS de componentes relacionados con gestión de usuarios

<<<<<<< HEAD
export { CreateUserForm } from './CreateUserForm';

;
=======
export { default as CreateUserForm } from '../../components/user/CreateUserForm';
>>>>>>> permisos-y-resposive
