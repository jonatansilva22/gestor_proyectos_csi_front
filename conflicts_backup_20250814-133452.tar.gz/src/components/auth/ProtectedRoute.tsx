// src/components/auth/ProtectedRoute.tsx
import { Navigate, useLocation } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { JSX, FC } from 'react';

interface ProtectedRouteProps {
  children: JSX.Element;
}

const ProtectedRoute: FC<ProtectedRouteProps> = ({ children }) => {
  const { isAuthenticated, isLoading } = useAuth();
  const location = useLocation();

<<<<<<< HEAD
=======

>>>>>>> permisos-y-resposive
  // Mientras está verificando la autenticación, muestra un indicador de carga
  if (isLoading) {
    return (
      <div className="flex justify-center items-center h-screen">
<<<<<<< HEAD
        <div className="animate-spin rounded-full h-10 w-10 border-t-2 border-b-2 border-primary"></div>
=======
        <div className="animate-spin rounded-full h-10 w-10 border-t-2 border-b-2 border-purple-600"></div>
>>>>>>> permisos-y-resposive
      </div>
    );
  }

  // Si no está autenticado, redirige al login
  if (!isAuthenticated) {
<<<<<<< HEAD
    return <Navigate to="/" state={{ from: location }} replace />;
=======
    return <Navigate to="/login" state={{ from: location }} replace />;
>>>>>>> permisos-y-resposive
  }

  // Si está autenticado, renderiza el componente hijo
  return children;
};

export default ProtectedRoute;