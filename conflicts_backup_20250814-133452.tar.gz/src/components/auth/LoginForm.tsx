import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { useTheme } from '../../context/ThemeContext';
import { validateLoginForm } from '../../utils/validation';
import { useValidationErrors } from '../../hooks/useValidationErrors';

const LoginForm: React.FC = () => {
<<<<<<< HEAD
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [rememberMe, setRememberMe] = useState(false);
  const { errors, clearErrors, clearFieldError, handleApiError, setBackendErrors } = useValidationErrors();
  const { login, isLoading } = useAuth();
  const { darkMode } = useTheme();
=======
  const { darkMode } = useTheme();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const { errors, clearErrors, clearFieldError, handleApiError, setBackendErrors } = useValidationErrors();
  const { login, isLoading } = useAuth();
>>>>>>> permisos-y-resposive
  const navigate = useNavigate();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    clearErrors();

    // Validación del frontend usando reglas del backend
    const validationResult = validateLoginForm({ email, password });
    
    if (!validationResult.isValid) {
      // Usar el manejador de errores de validación para validación del frontend
      setBackendErrors(validationResult.errors);
      return;
    }

    try {
<<<<<<< HEAD
      await login(email, password, rememberMe);
      navigate('/create-user'); // Redirección corregida según CLAUDE.md
=======
      await login(email, password, false);
      navigate('/dashboard');
>>>>>>> permisos-y-resposive
    } catch (error: any) {
      // Manejo mejorado de errores con soporte para validación del backend
      handleApiError(error);
    }
  };

  const togglePasswordVisibility = () => {
    setShowPassword(!showPassword);
  };

  return (
<<<<<<< HEAD
    <div className={`${darkMode ? 'bg-[#3A2864]' : 'bg-white'} p-6 border-t ${darkMode ? 'border-[#6F43D6]/20' : 'border-gray-200'}`}>
      <h2
        className={`text-center text-2xl font-bold mb-6 ${
          darkMode ? 'text-white' : 'text-[#000000]'
=======
    <div className="p-8">
      <h2
        className={`text-center text-2xl font-bold mb-6 ${
          darkMode ? 'text-purple-200' : 'text-gray-900'
>>>>>>> permisos-y-resposive
        }`}
      >
        Iniciar Sesión
      </h2>

      {(errors.general || errors.email || errors.password) && (
<<<<<<< HEAD
        <div className="mb-4 p-3 bg-red-100 border border-red-400 text-red-700 rounded-md text-sm shadow-sm">
=======
        <div className="mb-4 p-3 bg-red-50 text-red-700 border border-red-200 rounded-lg text-sm">
>>>>>>> permisos-y-resposive
          {errors.general || 'Por favor corrige los errores en el formulario'}
        </div>
      )}

      <form onSubmit={handleSubmit}>
        {/* --- Campo Email --- */}
        <div className="mb-4">
          <label
            className={`block text-sm font-medium mb-2 ${
<<<<<<< HEAD
              darkMode ? 'text-gray-300' : 'text-[#494949]'
=======
              darkMode ? 'text-purple-200' : 'text-gray-600'
>>>>>>> permisos-y-resposive
            }`}
          >
            Correo
          </label>
          <div className="relative">
            <div className="absolute inset-y-0 left-0 flex items-center pl-3">
              {/* Icono email */}
              <svg
                xmlns="http://www.w3.org/2000/svg"
<<<<<<< HEAD
                className="h-5 w-5 text-[#6F43D6]"
=======
                className="h-5 w-5 text-purple-500"
>>>>>>> permisos-y-resposive
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"
                />
              </svg>
            </div>
            <input
              type="email"
              value={email}
              onChange={(e) => {
                setEmail(e.target.value);
<<<<<<< HEAD
                // Limpiar error de email cuando el usuario comienza a escribir
                clearFieldError('email');
              }}
              placeholder="user@email.com"
              required
              className={`w-full py-2 pl-10 pr-3 border rounded-md shadow-sm focus:ring-[#6F43D6] focus:border-[#6F43D6] focus:outline-none
                ${errors.email ? 'border-red-500' : ''}
                ${
                  darkMode
                    ? 'bg-[#FFFFFF] border-gray-700 text-gray-900 placeholder-gray-400'
                    : 'bg-white border-gray-300 text-gray-900'
                }`}
=======
                clearFieldError('email');
              }}
              placeholder="usuario@correo.com"
              required
              className={`w-full py-3 pl-10 pr-3 border rounded-lg focus:outline-none transition-colors ${
                darkMode 
                  ? 'bg-[#3A2B5A] border-purple-600/50 text-white placeholder-gray-400 focus:border-purple-500'
                  : 'bg-white border-gray-300 text-gray-900 placeholder-gray-500 focus:border-purple-500'
              }
                ${errors.email ? 'border-red-400' : ''}`}
>>>>>>> permisos-y-resposive
              disabled={isLoading}
            />
          </div>
          {errors.email && (
<<<<<<< HEAD
            <p className="mt-1 text-sm text-red-600">{errors.email}</p>
=======
            <p className="mt-1 text-sm text-red-500">{errors.email}</p>
>>>>>>> permisos-y-resposive
          )}
        </div>

        {/* --- Campo Contraseña --- */}
        <div className="mb-4">
          <label
            className={`block text-sm font-medium mb-2 ${
<<<<<<< HEAD
              darkMode ? 'text-gray-300' : 'text-[#494949]'
=======
              darkMode ? 'text-purple-200' : 'text-gray-600'
>>>>>>> permisos-y-resposive
            }`}
          >
            Contraseña
          </label>
          <div className="relative">
            <div className="absolute inset-y-0 left-0 flex items-center pl-3">
              <svg
                xmlns="http://www.w3.org/2000/svg"
<<<<<<< HEAD
                className="h-5 w-5 text-[#6F43D6]"
=======
                className="h-5 w-5 text-purple-500"
>>>>>>> permisos-y-resposive
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"
                />
              </svg>
            </div>
            <input
              type={showPassword ? "text" : "password"}
              value={password}
              onChange={(e) => {
                setPassword(e.target.value);
<<<<<<< HEAD
                // Limpiar error de contraseña cuando el usuario comienza a escribir
                clearFieldError('password');
              }}
              placeholder="******************"
              required
              className={`w-full py-2 pl-10 pr-10 border rounded-md shadow-sm focus:ring-[#6F43D6] focus:border-[#6F43D6] focus:outline-none
                ${errors.password ? 'border-red-500' : ''}
                ${
                  darkMode
                    ? 'bg-[#FFFFFF] border-gray-700 text-gray-900 placeholder-gray-400'
                    : 'bg-white border-gray-300 text-gray-900'
                }`}
=======
                clearFieldError('password');
              }}
              placeholder="Ingresa tu contraseña"
              required
              className={`w-full py-3 pl-10 pr-10 border rounded-lg focus:outline-none transition-colors ${
                darkMode 
                  ? 'bg-[#3A2B5A] border-purple-600/50 text-white placeholder-gray-400 focus:border-purple-500'
                  : 'bg-white border-gray-300 text-gray-900 placeholder-gray-500 focus:border-purple-500'
              }
                ${errors.password ? 'border-red-400' : ''}`}
>>>>>>> permisos-y-resposive
              disabled={isLoading}
            />
            <button
              type="button"
              onClick={togglePasswordVisibility}
              className="absolute inset-y-0 right-0 flex items-center pr-3"
            >
              {showPassword ? (
                <svg
                  xmlns="http://www.w3.org/2000/svg"
<<<<<<< HEAD
                  className="h-5 w-5 text-[#6F43D6]"
=======
                  className="h-5 w-5 text-purple-500"
>>>>>>> permisos-y-resposive
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
<<<<<<< HEAD
                    d="M13.875 18.825A10.05 10.05 0 0112 19c-4.478 0-8.268-2.943-9.543-7a9.97 9.97 0 011.563-3.029m5.858.908a3 3 0 114.243 4.243M9.878 9.878l4.242 4.242M9.88 9.88l-3.29-3.29m7.532 7.532l3.29 3.29M3 3l3.59 3.59m0 0A9.953 9.953 0 0112 5c4.478 0 8.268 2.943 9.543 7a10.025 10.025 0 01-4.132 5.411m0 0L21 21"
=======
                    d="M13.875 18.825A10.05 10.05 0 0112 19c-4.478 0-8.268-2.943-9.543-7a9.97 9.97 0 011.563-3.029m5.858.908a3 3 0 114.243 4.243M9.878 9.878l4.242 4.242M9.88 9.88l-3.29-3.29m7.532 7.532l3.29 3.29M3 3l3.59 3.59m0 0A9.953 9.953 0 0112 5c4.478 0 8.268 2.943 9.542 7a10.025 10.025 0 01-4.132 5.411m0 0L21 21"
>>>>>>> permisos-y-resposive
                  />
                </svg>
              ) : (
                <svg
                  xmlns="http://www.w3.org/2000/svg"
<<<<<<< HEAD
                  className="h-5 w-5 text-[#6F43D6]"
=======
                  className="h-5 w-5 text-purple-500"
>>>>>>> permisos-y-resposive
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"
                  />
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"
                  />
                </svg>
              )}
            </button>
          </div>
          {errors.password && (
<<<<<<< HEAD
            <p className="mt-1 text-sm text-red-600">{errors.password}</p>
          )}
        </div>

        {/* --- Recordarme --- */}
        <div className="mb-6">
          <label className="flex items-center cursor-pointer">
            <div className="relative flex items-center">
              <input
                type="checkbox"
                checked={rememberMe}
                onChange={() => setRememberMe(!rememberMe)}
                className="sr-only"
                disabled={isLoading}
              />
              <div
                className={`w-4 h-4 border rounded ${
                  rememberMe
                    ? darkMode
                      ? 'bg-black border-black'
                      : 'bg-[#6F43D6] border-[#6F43D6]'
                    : darkMode
                    ? 'border-gray-600'
                    : 'border-gray-400'
                }`}
              >
                {rememberMe && (
                  <svg
                    className="w-4 h-4 text-white fill-current"
                    viewBox="0 0 20 20"
                  >
                    <path d="M0 11l2-2 5 5L18 3l2 2L7 18z" />
                  </svg>
                )}
              </div>
              <span
                className={`ml-2 text-sm ${
                  darkMode ? 'text-gray-300' : 'text-[#494949]'
                }`}
              >
                Recuérdame
              </span>
            </div>
          </label>
        </div>
=======
            <p className="mt-1 text-sm text-red-500">{errors.password}</p>
          )}
        </div>

        {/* Forgot password link removido por solicitud */}
>>>>>>> permisos-y-resposive

        {/* --- Botón Enviar --- */}
        <button
          type="submit"
          disabled={isLoading}
<<<<<<< HEAD
          className="w-full py-2 px-4 bg-[#6F43D6] hover:bg-[#5F36C4] text-white font-medium rounded-md shadow-md
            focus:outline-none transition-colors disabled:opacity-70 disabled:cursor-not-allowed"
        >
          {isLoading ? 'Accediendo...' : 'Acceder'}
=======
          className={`w-full py-3 px-4 text-white font-semibold rounded-lg transition-all duration-200 shadow-lg disabled:opacity-50 disabled:cursor-not-allowed ${
            darkMode
              ? 'bg-gradient-to-r from-purple-500 to-purple-600 hover:from-purple-600 hover:to-purple-700 shadow-purple-900/30'
              : 'bg-gradient-to-r from-purple-600 to-purple-700 hover:from-purple-700 hover:to-purple-800'
          }`}
        >
          {isLoading ? (
            <div className="flex items-center justify-center gap-2">
              <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
              Accediendo...
            </div>
          ) : (
            'Acceder'
          )}
>>>>>>> permisos-y-resposive
        </button>
      </form>
    </div>
  );
};

<<<<<<< HEAD
export default LoginForm;
=======
export default LoginForm;
>>>>>>> permisos-y-resposive
