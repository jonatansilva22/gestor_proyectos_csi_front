import { useNavigate } from 'react-router-dom';
<<<<<<< HEAD
=======
import DeleteButton from '../DeleteButton';
>>>>>>> permisos-y-resposive

interface EntityActionsProps {
  id?: string | number;
  onEdit?: () => void;
  onDelete?: () => void;
  detailsPath?: string;
  detailsLabel?: string;
<<<<<<< HEAD
  deleteIcon?: string;
=======
>>>>>>> permisos-y-resposive
  showDetails?: boolean;
  showEdit?: boolean;
  showDelete?: boolean;
}

export const EntityActions = ({
<<<<<<< HEAD
=======
  id,
>>>>>>> permisos-y-resposive
  onEdit,
  onDelete,
  detailsPath,
  detailsLabel = "Ver Detalles",
<<<<<<< HEAD
  deleteIcon = "🗑️",
=======
>>>>>>> permisos-y-resposive
  showDetails = false,
  showEdit = true,
  showDelete = true,
}: EntityActionsProps) => {
  const navigate = useNavigate();

  const handleDetailsClick = () => {
    if (detailsPath) {
      navigate(detailsPath);
    }
  };

  return (
<<<<<<< HEAD
    <div className="flex space-x-2">
      {showDetails && (
        <button
          onClick={handleDetailsClick}
          className="bg-purple-600 hover:bg-purple-700 text-white px-3 py-1 rounded-md text-sm transition-colors"
=======
    <div className="flex flex-col sm:flex-row gap-2 items-center justify-center">
      {showDetails && (
        <button
          onClick={handleDetailsClick}
          className="w-full sm:w-auto px-4 py-2 bg-purple-600 hover:bg-purple-700 text-white rounded-lg text-sm font-medium transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-purple-500 focus:ring-offset-1 active:scale-95"
>>>>>>> permisos-y-resposive
        >
          {detailsLabel}
        </button>
      )}
      
      {showEdit && onEdit && (
        <button
          onClick={onEdit}
<<<<<<< HEAD
          className="bg-blue-600 hover:bg-blue-700 text-white px-3 py-1 rounded-md text-sm transition-colors"
=======
          className="w-full sm:w-auto px-4 py-2 bg-purple-600 hover:bg-purple-700 text-white rounded-lg text-sm font-medium transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-purple-500 focus:ring-offset-1 active:scale-95"
>>>>>>> permisos-y-resposive
        >
          Editar
        </button>
      )}
      
      {showDelete && onDelete && (
<<<<<<< HEAD
        <button
          onClick={onDelete}
          className="bg-red-600 hover:bg-red-700 text-white px-3 py-1 rounded-md text-sm transition-colors"
        >
          {deleteIcon}
        </button>
=======
        <div className="w-full sm:w-auto flex justify-center">
          <DeleteButton
            onDelete={onDelete}
            ariaLabel={`Eliminar elemento ${id || ''}`}
            size="md"
          />
        </div>
>>>>>>> permisos-y-resposive
      )}
    </div>
  );
};