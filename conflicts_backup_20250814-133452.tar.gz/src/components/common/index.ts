// src/components/common/index.ts
// 🧩 EXPORTS de componentes comunes reutilizables

export { AuthInput } from './AuthInput';
export { Checkbox } from './Checkbox';
export { FormInput } from './FormInput';
export { FormSelect } from './FormSelect';
export { FileUpload } from './FileUpload';
<<<<<<< HEAD
export { EntityActions } from './EntityActions';
=======
export { EntityActions } from './EntityActions';
export { default as DeleteButton } from './DeleteButton';
export { default as ResponsiveTable } from './ResponsiveTable';
>>>>>>> permisos-y-resposive
