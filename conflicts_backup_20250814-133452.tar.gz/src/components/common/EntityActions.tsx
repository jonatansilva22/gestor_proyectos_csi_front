import { useNavigate } from "react-router-dom";
<<<<<<< HEAD
=======
import DeleteButton from "./DeleteButton";
>>>>>>> permisos-y-resposive

interface EntityActionsProps {
  id: number;
  onDelete: () => void;
  detailsPath?: string;
  detailsLabel?: string;
<<<<<<< HEAD
  deleteIcon?: string;
  onDetails?: () => void; 
=======
  onDetails?: () => void;
>>>>>>> permisos-y-resposive
}

export const EntityActions = ({
  id,
  onDelete,
  detailsPath,
  detailsLabel = "Ver Detalles",
<<<<<<< HEAD
  deleteIcon,
=======
>>>>>>> permisos-y-resposive
  onDetails,
}: EntityActionsProps) => {
  const navigate = useNavigate();

  return (
<<<<<<< HEAD
    <div className="flex gap-3 items-center justify-center">
      <button
        className="bg-purple-600 text-white px-6 py-2 rounded-full font-semibold hover:bg-purple-700 transition cursor-pointer"
        onClick={onDetails ? onDetails : () => detailsPath && navigate(detailsPath)}
      >
        {detailsLabel}
      </button>
      <button
        className="rounded-full p-1 hover:bg-red-100 transition flex items-center justify-center cursor-pointer"
        onClick={onDelete}
      >
        {deleteIcon ? (
          <img src={deleteIcon} alt="Eliminar" className="w-10 h-10" />
        ) : (
          <span role="img" aria-label="Eliminar" className="text-2xl">🗑️</span>
        )}
      </button>
=======
    <div className="flex flex-col sm:flex-row gap-2 sm:gap-3 items-center justify-center w-full sm:w-auto">
      <button
        className="w-full sm:w-auto min-w-[120px] px-4 py-3 sm:px-6 sm:py-2 text-base sm:text-sm font-medium rounded-lg transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-offset-1 active:scale-95 min-h-[44px] bg-purple-600 text-white hover:bg-purple-700 
                   focus:ring-purple-500 focus:ring-offset-white dark:focus:ring-purple-400 
                   dark:focus:ring-offset-gray-800 font-semibold"
        onClick={onDetails ? onDetails : () => detailsPath && navigate(detailsPath)}
        aria-label={`${detailsLabel} para elemento ${id}`}
      >
        {detailsLabel}
      </button>
      <div className="w-full sm:w-auto flex justify-center">
        <DeleteButton
          onDelete={onDelete}
          ariaLabel={`Eliminar elemento ${id}`}
          size="md"
        />
      </div>
>>>>>>> permisos-y-resposive
    </div>
  );
};