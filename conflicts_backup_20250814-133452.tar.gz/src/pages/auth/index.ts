// src/pages/auth/index.ts
<<<<<<< HEAD
export { default as Login } from './Login';
export { default as LogoutPage } from './LogoutPage';
=======
export { default as Login } from '../../pages/auth/Login';
export { default as LogoutPage } from '../../pages/auth/LogoutPage';
>>>>>>> permisos-y-resposive
