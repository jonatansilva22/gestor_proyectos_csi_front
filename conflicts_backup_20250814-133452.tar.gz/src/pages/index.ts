// src/pages/index.ts
// Authentication pages
export * from './auth';

// User management pages
export * from './users';

<<<<<<< HEAD
// Permissions management pages
export * from './permissions';

// General pages
export { default as Dashboard } from './Dashboard';
=======

// General pages
export { default as Dashboard } from './Dashboard';
export { default as NotFound } from './NotFound';
>>>>>>> permisos-y-resposive
