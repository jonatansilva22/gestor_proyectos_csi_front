// src/pages/users/index.ts
<<<<<<< HEAD
export { default as CreateUser } from './CreateUser';
=======
export { default as CreateUser } from '../../pages/users/CreateUser';
>>>>>>> permisos-y-resposive

// Import corrections for user components
export { FormInput } from '../../components/common/user/FormInput';
export { EntityActions } from '../../components/common/user/EntityActions';