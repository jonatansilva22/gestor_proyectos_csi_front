<<<<<<< HEAD
import axios from 'axios';
import { Area } from '../../types/areas/Area';

const API_URL = import.meta.env.VITE_API_URL;

export const getAreas = async (): Promise<Area[]> => {
  const { data } = await axios.get<Area[]>(`${API_URL}/areas/`);
=======
import api from '../api';
import { Area } from '../../types/areas/Area';

export const getAreas = async (): Promise<Area[]> => {
  const { data } = await api.get<Area[]>('/areas/');
>>>>>>> permisos-y-resposive
  return data;
};

export const getAreaById = async (id: number): Promise<Area> => {
<<<<<<< HEAD
  const { data } = await axios.get<Area>(`${API_URL}/areas/${id}/`);
=======
  const { data } = await api.get<Area>(`/areas/${id}/`);
>>>>>>> permisos-y-resposive
  return data;
};

export const createArea = async (area: { name: string }) => {
<<<<<<< HEAD
  const { data } = await axios.post(`${API_URL}/areas/`, area, {
=======
  const { data } = await api.post('/areas/', area, {
>>>>>>> permisos-y-resposive
    headers: { "Content-Type": "application/json" },
  });
  return data;
};

export const deleteArea = async (id: number) => {
<<<<<<< HEAD
  await axios.delete(`${API_URL}/areas/${id}/`);
};

export async function updateArea(id: number, data: Partial<Area>) {
  const response = await axios.patch(`${API_URL}/areas/${id}/`, data, {
=======
  await api.delete(`/areas/${id}/`);
};

export async function updateArea(id: number, data: Partial<Area>) {
  const response = await api.patch(`/areas/${id}/`, data, {
>>>>>>> permisos-y-resposive
    headers: { "Content-Type": "application/json" },
  });
  return response.data;
}