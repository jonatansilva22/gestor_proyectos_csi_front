<<<<<<< HEAD
import axios from 'axios';
import { Tool } from '../../types/tools/Tool';

const API_URL = import.meta.env.VITE_API_URL;

export const getTools = async (): Promise<Tool[]> => {
  const { data } = await axios.get<Tool[]>(`${API_URL}/tools/`);
=======
import api from '../api';
import { Tool } from '../../types/tools/Tool';

export const getTools = async (): Promise<Tool[]> => {
  const { data } = await api.get<Tool[]>('/tools/');
>>>>>>> permisos-y-resposive
  return data;
};

export const getToolById = async (id: number): Promise<Tool> => {
<<<<<<< HEAD
  const { data } = await axios.get<Tool>(`${API_URL}/tools/${id}/`);
=======
  const { data } = await api.get<Tool>(`/tools/${id}/`);
>>>>>>> permisos-y-resposive
  return data;
};

export const createTool = async (tool: { name: string; image: File | null }) => {
  const formData = new FormData();
  formData.append("name", tool.name);
  if (tool.image) {
    formData.append("image", tool.image);
  }

<<<<<<< HEAD
  const { data } = await axios.post(`${API_URL}/tools/`, formData);
=======
  const { data } = await api.post('/tools/', formData, {
    headers: {
      'Content-Type': 'multipart/form-data',
    },
  });
>>>>>>> permisos-y-resposive
  return data;
};

export const deleteTool = async (id: number) => {
<<<<<<< HEAD
  await axios.delete(`${API_URL}/tools/${id}/`);
=======
  await api.delete(`/tools/${id}/`);
>>>>>>> permisos-y-resposive
};

export async function updateTool(id: number, data: { name?: string; image?: File | null }) {
  const formData = new FormData();
  if (data.name !== undefined) formData.append("name", data.name);
  if (data.image) formData.append("image", data.image);

<<<<<<< HEAD
  const response = await axios.patch(`${API_URL}/tools/${id}/`, formData);
  return response.data;
}
=======
  const response = await api.patch(`/tools/${id}/`, formData, {
    headers: {
      'Content-Type': 'multipart/form-data',
    },
  });
  return response.data;
}
>>>>>>> permisos-y-resposive
