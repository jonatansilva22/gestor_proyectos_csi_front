<<<<<<< HEAD
import axios from 'axios';
import { Group } from '../../types/groups/Group';
import { User } from '../../types/user';

const API_URL = import.meta.env.VITE_API_URL;

export const getGroups = async (): Promise<Group[]> => {
  const { data } = await axios.get<Group[]>(`${API_URL}/groups/`);
=======
import api from '../api';
import { Group } from '../../types/groups/Group';
import { User } from '../../types/user';

export const getGroups = async (): Promise<Group[]> => {
  const { data } = await api.get<Group[]>('/groups/');
>>>>>>> permisos-y-resposive
  return data;
};

export const getGroupById = async (id: number): Promise<Group> => {
<<<<<<< HEAD
  const { data } = await axios.get<Group>(`${API_URL}/groups/${id}/`);
=======
  const { data } = await api.get<Group>(`/groups/${id}/`);
>>>>>>> permisos-y-resposive
  return data;
};

export const createGroup = async (group: { name: string; user_ids: number[] }) => {
<<<<<<< HEAD
  const { data } = await axios.post(`${API_URL}/groups/`, group, {
=======
  const { data } = await api.post('/groups/', group, {
>>>>>>> permisos-y-resposive
    headers: { 'Content-Type': 'application/json' },
  });
  return data;
};

export const updateGroup = async (id: number, group: { name: string; user_ids: number[] }) => {
<<<<<<< HEAD
  const { data } = await axios.patch(`${API_URL}/groups/${id}/`, group, {
=======
  const { data } = await api.patch(`/groups/${id}/`, group, {
>>>>>>> permisos-y-resposive
    headers: { 'Content-Type': 'application/json' },
  });
  return data;
};

export const deleteGroup = async (id: number) => {
<<<<<<< HEAD
  await axios.delete(`${API_URL}/groups/${id}/`);
};

export const getUsers = async (): Promise<User[]> => {
  const { data } = await axios.get<User[]>(`${API_URL}/create-user/`);
  return data;
};
=======
  await api.delete(`/groups/${id}/`);
};

export const getUsers = async (): Promise<User[]> => {
  const { data } = await api.get<User[]>('/create-user/');
  return data;
};
>>>>>>> permisos-y-resposive
