<<<<<<< HEAD
import axios from 'axios';
import { Repository } from '../../types/repositories/Repository';

const API_URL = import.meta.env.VITE_API_URL;

export const getRepositories = async (): Promise<Repository[]> => {
  const { data } = await axios.get<Repository[]>(`${API_URL}/repositories/`);
=======
import api from '../api';
import { Repository } from '../../types/repositories/Repository';

export const getRepositories = async (): Promise<Repository[]> => {
  const { data } = await api.get<Repository[]>('/repositories/');
>>>>>>> permisos-y-resposive
  return data;
};

export const getRepositoryById = async (id: number): Promise<Repository> => {
<<<<<<< HEAD
  const { data } = await axios.get<Repository>(`${API_URL}/repositories/${id}/`);
=======
  const { data } = await api.get<Repository>(`/repositories/${id}/`);
>>>>>>> permisos-y-resposive
  return data;
};

export const createRepository = async (repository: {
  name: string;
  repository_url: string;
  project: number;
}) => {
<<<<<<< HEAD
  const { data } = await axios.post(`${API_URL}/repositories/`, repository, {
=======
  const { data } = await api.post('/repositories/', repository, {
>>>>>>> permisos-y-resposive
    headers: { 'Content-Type': 'application/json' },
  });
  return data;
};

export const updateRepository = async (
  id: number,
  repository: Partial<Repository>
) => {
<<<<<<< HEAD
  const { data } = await axios.patch(`${API_URL}/repositories/${id}/`, repository, {
=======
  const { data } = await api.patch(`/repositories/${id}/`, repository, {
>>>>>>> permisos-y-resposive
    headers: { 'Content-Type': 'application/json' },
  });
  return data;
};

export const deleteRepository = async (id: number) => {
<<<<<<< HEAD
  await axios.delete(`${API_URL}/repositories/${id}/`);
};
=======
  await api.delete(`/repositories/${id}/`);
};
>>>>>>> permisos-y-resposive
