// src/services/index.ts
// 🔧 EXPORTS de todos los servicios de la aplicación

export { authService } from "./auth";
export { userService } from "./users";
<<<<<<< HEAD
export { permissionsService } from "./permissions";
=======
>>>>>>> permisos-y-resposive
export { default as api } from "./api";


