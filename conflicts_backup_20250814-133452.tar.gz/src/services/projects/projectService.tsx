<<<<<<< HEAD
import axios from 'axios';
import { Project, Area, Tool, Repository, Group } from '../../types/projects/Project';

const API_URL = import.meta.env.VITE_API_URL;

export const getProjects = async (): Promise<Project[]> => {
  const { data } = await axios.get<Project[]>(`${API_URL}/projects/`);
=======
import api from '../api';
import { Project, Area, Tool, Repository, Group } from '../../types/projects/Project';

export const getProjects = async (): Promise<Project[]> => {
  const { data } = await api.get<Project[]>('/projects/');
>>>>>>> permisos-y-resposive
  return data;
};

export const getProjectById = async (id: number): Promise<Project> => {
<<<<<<< HEAD
  const { data } = await axios.get<Project>(`${API_URL}/projects/${id}/`);
=======
  const { data } = await api.get<Project>(`/projects/${id}/`);
>>>>>>> permisos-y-resposive
  return data;
};

export const createProject = async (project: FormData) => {
<<<<<<< HEAD
  const { data } = await axios.post(`${API_URL}/projects/`, project, {
=======
  const { data } = await api.post('/projects/', project, {
>>>>>>> permisos-y-resposive
    headers: { "Content-Type": "multipart/form-data" },
  });
  return data;
};

export const deleteProject = async (id: number) => {
<<<<<<< HEAD
  await axios.delete(`${API_URL}/projects/${id}/`);
=======
  await api.delete(`/projects/${id}/`);
>>>>>>> permisos-y-resposive
};

export const updateProject = async (id: number, data: any) => {
  // Detectar si es FormData para setear headers correcto
  const isFormData = data instanceof FormData;
  const headers = isFormData
    ? { "Content-Type": "multipart/form-data" }
    : { "Content-Type": "application/json" };

<<<<<<< HEAD
  const { data: response } = await axios.patch(`${API_URL}/projects/${id}/`, data, {
=======
  const { data: response } = await api.patch(`/projects/${id}/`, data, {
>>>>>>> permisos-y-resposive
    headers,
  });
  return response;
};

export const getStatusTypes = async (): Promise<{ id: number; name: string }[]> => {
<<<<<<< HEAD
  const { data } = await axios.get<{ id: number; name: string }[]>(`${API_URL}/status-types/`);
=======
  const { data } = await api.get<{ id: number; name: string }[]>('/status-types/');
>>>>>>> permisos-y-resposive
  return data;
};

export const getAreas = async (): Promise<Area[]> => {
<<<<<<< HEAD
  const { data } = await axios.get<Area[]>(`${API_URL}/areas/`);
=======
  const { data } = await api.get<Area[]>('/areas/');
>>>>>>> permisos-y-resposive
  return data;
};

export const getTools = async (): Promise<Tool[]> => {
<<<<<<< HEAD
  const { data } = await axios.get<Tool[]>(`${API_URL}/tools/`);
=======
  const { data } = await api.get<Tool[]>('/tools/');
>>>>>>> permisos-y-resposive
  return data;
};

export const getGroups = async (): Promise<Group[]> => {
<<<<<<< HEAD
  const { data } = await axios.get<Group[]>(`${API_URL}/groups/`);
=======
  const { data } = await api.get<Group[]>('/groups/');
>>>>>>> permisos-y-resposive
  return data;
};

export const getRepositories = async (): Promise<Repository[]> => {
<<<<<<< HEAD
  const { data } = await axios.get<Repository[]>(`${API_URL}/repositories/`);
  return data;
};
=======
  const { data } = await api.get<Repository[]>('/repositories/');
  return data;
};
>>>>>>> permisos-y-resposive
