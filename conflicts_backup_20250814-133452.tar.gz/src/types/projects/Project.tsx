export interface ProjectStatus {
  id: number;
  name: string;
}

export interface Project {
  id: number;
  name: string;
  image: string | null;
  description: string;
  project_owner: number;
<<<<<<< HEAD
  group: number;
  status: ProjectStatus;
  start_date: string;
  end_date: string;
=======
  group: Group | number | null;
  status: ProjectStatus;
  start_date: string;
  end_date: string;
  index?: number;
  tools?: Tool[];
  area?: Area;
  areas?: Area[];
  repositories?: Repository[];
  users?: any[];
>>>>>>> permisos-y-resposive
}

export interface Area {
  id: number;
  name: string;
}

export interface Tool {
  id: number;
  name: string;
}

export interface Group {
  id: number;
  name: string;
<<<<<<< HEAD
=======
  users?: any[];
>>>>>>> permisos-y-resposive
}

export interface Repository {
  id: number;
  name: string;
<<<<<<< HEAD
}
=======
}
>>>>>>> permisos-y-resposive
