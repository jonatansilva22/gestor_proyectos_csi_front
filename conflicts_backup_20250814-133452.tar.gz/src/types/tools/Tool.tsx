export interface Tool {
  id: number;
  name: string;
  image: string; 
  created_at: string;
  updated_at: string;
<<<<<<< HEAD
=======
  index?: number;
>>>>>>> permisos-y-resposive
}

export interface ToolFormValues {
  name: string;
  image: File | null;
<<<<<<< HEAD
}
=======
}
>>>>>>> permisos-y-resposive
