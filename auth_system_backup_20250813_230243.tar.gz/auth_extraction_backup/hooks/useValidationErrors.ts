// src/hooks/useValidationErrors.ts
import { useState } from 'react';
import { toast } from 'react-toastify';

interface ValidationErrors {
  [key: string]: string | undefined;
}

export const useValidationErrors = () => {
  const [errors, setErrors] = useState<ValidationErrors>({});

  // Clear all errors
  const clearErrors = () => {
    setErrors({});
  };

  // Clear error for specific field
  const clearFieldError = (fieldName: string) => {
    if (errors[fieldName]) {
      setErrors(prev => {
        const newErrors = { ...prev };
        delete newErrors[fieldName];
        return newErrors;
      });
    }
  };

  // Set errors from backend response or frontend validation
  const setBackendErrors = (backendErrors: ValidationErrors) => {
    setErrors(backendErrors);
  };

  // Set a single field error
  const setFieldError = (fieldName: string, errorMessage: string) => {
    setErrors(prev => ({
      ...prev,
      [fieldName]: errorMessage
    }));
  };

  // Handle API errors with validation support
  const handleApiError = (error: any) => {
    console.error('API Error:', error);

    // Check if error has validation errors from our enhanced services
    if (error.validationErrors) {
      setBackendErrors(error.validationErrors);
      const fieldCount = Object.keys(error.validationErrors).length;
      toast.error(
        fieldCount === 1 
          ? 'Se encontró un error en el formulario. Por favor corrígelo.' 
          : `Se encontraron ${fieldCount} errores en el formulario. Por favor corrígelos.`,
        {
          autoClose: 5000,
          position: "top-center"
        }
      );
      return;
    }

    // Check for specific backend error messages
    if (error.response?.data?.message) {
      toast.error(error.response.data.message, {
        autoClose: 4000,
        position: "top-center"
      });
      return;
    }

    // Handle specific error messages
    if (error.message) {
      toast.error(error.message, {
        autoClose: 4000,
        position: "top-center"
      });
      return;
    }

    // Handle HTTP status codes with more specific messages
    if (error.response?.status) {
      switch (error.response.status) {
        case 400:
          // Check for specific 400 error details
          if (error.response.data?.detail) {
            toast.error(error.response.data.detail, {
              autoClose: 5000,
              position: "top-center"
            });
          } else {
            toast.error('Los datos enviados contienen errores. Verifica la información.', {
              autoClose: 4000,
              position: "top-center"
            });
          }
          break;
        case 401:
          toast.error('Credenciales inválidas o sesión expirada', {
            autoClose: 4000,
            position: "top-center"
          });
          break;
        case 403:
          toast.error('No tienes permisos suficientes para realizar esta acción', {
            autoClose: 4000,
            position: "top-center"
          });
          break;
        case 404:
          toast.error('El recurso solicitado no fue encontrado', {
            autoClose: 4000,
            position: "top-center"
          });
          break;
        case 409:
          toast.error('Ya existe un recurso con estos datos. Verifica la información.', {
            autoClose: 5000,
            position: "top-center"
          });
          break;
        case 422:
          toast.error('Los datos enviados no cumplen con los requisitos del sistema', {
            autoClose: 5000,
            position: "top-center"
          });
          break;
        case 500:
          toast.error('Error interno del servidor. El equipo técnico ha sido notificado.', {
            autoClose: 6000,
            position: "top-center"
          });
          break;
        case 502:
        case 503:
          toast.error('Servicio temporalmente no disponible. Intenta nuevamente en unos minutos.', {
            autoClose: 6000,
            position: "top-center"
          });
          break;
        default:
          toast.error(`Error inesperado (${error.response.status}). Por favor intenta nuevamente.`, {
            autoClose: 4000,
            position: "top-center"
          });
      }
      return;
    }

    // Manejo especial para timeouts que pueden ser éxitos
    if (error.possibleSuccess) {
      toast.warning(error.message, {
        autoClose: 8000,
        position: "top-center"
      });
      return;
    }
    
    // Generic error message
    toast.error('Error de conexión. Verifica tu internet e intenta nuevamente.', {
      autoClose: 4000,
      position: "top-center"
    });
  };

  return {
    errors,
    setErrors,
    clearErrors,
    clearFieldError,
    setFieldError,
    setBackendErrors,
    handleApiError,
    hasErrors: Object.keys(errors).length > 0
  };
};

export default useValidationErrors;