# CSI Project Manager - Authentication System Documentation

## Overview
This authentication system provides JWT-based authentication with role-based access control for the CSI Project Manager frontend application.

## Architecture

### Core Features
- JWT token-based authentication
- Role-based access control (SuperAdmin, Admin, Colaborador)
- Persistent sessions with localStorage/sessionStorage
- Automatic token refresh and 401 handling
- Theme-aware UI components
- Comprehensive form validation

### Tech Stack
- React 19 + TypeScript
- Axios for HTTP requests
- React Context for state management
- React Router DOM for protected routing

## File Structure

```
auth_extraction_backup/
├── components/
│   ├── auth/
│   │   ├── LoginForm.tsx          # Main login form component
│   │   ├── ProtectedRoute.tsx     # Authentication route wrapper
│   │   ├── RoleProtectedRoute.tsx # Role-based route wrapper
│   │   └── index.ts              # Component exports
│   └── common/
│       └── AuthInput.tsx         # Reusable input with icons
├── pages/
│   ├── auth/
│   │   ├── Login.tsx             # Login page with theme toggle
│   │   ├── LogoutPage.tsx        # Logout confirmation page
│   │   └── index.ts              # Page exports
│   └── Login.tsx                 # Legacy login page
├── services/
│   ├── auth/
│   │   ├── authService.ts        # Authentication API service
│   │   └── index.ts              # Service exports
│   └── api.ts                    # Axios configuration with interceptors
├── context/
│   └── AuthContext.tsx           # Global authentication state
├── types/
│   └── auth.ts                   # TypeScript type definitions
├── utils/
│   ├── storage.ts                # Token and user data persistence
│   └── validation.ts             # Form validation functions
├── hooks/
│   └── useValidationErrors.ts    # Validation error handling hook
└── AUTH_SYSTEM_DOCUMENTATION.md  # This documentation
```

## Key Components

### 1. AuthContext (`context/AuthContext.tsx`)
Global authentication state management:
- User data storage
- Login/logout functions
- Token management
- Authentication status

### 2. LoginForm (`components/auth/LoginForm.tsx`)
Main login form with:
- Email and password fields
- "Remember me" checkbox
- Form validation
- Dark theme support
- Loading states

### 3. Protected Routes
- `ProtectedRoute`: Requires authentication
- `RoleProtectedRoute`: Requires specific user roles

### 4. Authentication Service (`services/auth/authService.ts`)
API integration for:
- User login
- User logout
- Token refresh
- User data retrieval

### 5. API Configuration (`services/api.ts`)
Axios instance with:
- JWT token interceptors
- Automatic 401 handling
- Token refresh logic

## User Roles

1. **SuperAdmin (role: 1)**: Full system access
2. **Admin (role: 2)**: Administrative privileges
3. **Colaborador (role: 3)**: Basic user access

## Environment Configuration

Required environment variables:
```bash
VITE_API_URL=http://localhost:8000/api
```

## Backend Integration

### API Endpoints
- `POST /api/login/` - User authentication
- `POST /api/logout/` - User logout
- `POST /api/token/refresh/` - Token refresh
- `GET /api/user/{id}/` - Get user data

### Response Format
```typescript
interface LoginResponse {
  access: string;
  refresh: string;
  user: AuthUser;
}

interface AuthUser {
  id: number;
  email: string;
  first_name: string;
  last_name: string;
  role: 1 | 2 | 3;
}
```

## Security Features

### Token Management
- Access tokens stored in memory (AuthContext)
- Refresh tokens in localStorage/sessionStorage
- Automatic token refresh before expiration
- Secure token removal on logout

### Route Protection
- Automatic redirect to login for unauthenticated users
- Role-based access control for sensitive routes
- 401 response handling with automatic logout

### Form Validation
- Email format validation
- Password requirements
- Frontend and backend error handling
- CSRF protection (if configured in backend)

## Usage Examples

### Basic Setup
```tsx
// App.tsx
import { AuthProvider } from './context/AuthContext';
import { ProtectedRoute } from './components/auth';

function App() {
  return (
    <AuthProvider>
      <Router>
        <Routes>
          <Route path="/login" element={<Login />} />
          <Route path="/dashboard" element={
            <ProtectedRoute>
              <Dashboard />
            </ProtectedRoute>
          } />
        </Routes>
      </Router>
    </AuthProvider>
  );
}
```

### Role-Based Protection
```tsx
// Admin-only route
<RoleProtectedRoute allowedRoles={[1, 2]}>
  <AdminPanel />
</RoleProtectedRoute>
```

### Using Auth Context
```tsx
const { user, login, logout, isAuthenticated } = useAuth();

const handleLogin = async (credentials) => {
  try {
    await login(credentials);
    navigate('/dashboard');
  } catch (error) {
    setError('Invalid credentials');
  }
};
```

## Migration Guide

To integrate this authentication system into a new project:

1. **Install Dependencies**:
   ```bash
   npm install axios react-router-dom
   ```

2. **Copy Files**: Copy all files from this backup to your project

3. **Environment Setup**: Configure `VITE_API_URL` in your `.env` file

4. **Wrap Your App**: Add `AuthProvider` to your root component

5. **Configure Routes**: Use `ProtectedRoute` and `RoleProtectedRoute` as needed

6. **Backend Integration**: Ensure your Django backend has matching endpoints

## Troubleshooting

### Common Issues
1. **401 Errors**: Check token expiration and refresh logic
2. **CORS Issues**: Configure backend CORS settings
3. **Routing Problems**: Ensure React Router is properly configured
4. **Token Storage**: Verify localStorage/sessionStorage permissions

### Debug Tips
- Check browser console for authentication errors
- Verify API endpoint URLs match backend configuration
- Test token refresh functionality
- Validate user roles and permissions

## Additional Notes

- The system supports both "remember me" (localStorage) and session-only (sessionStorage) authentication
- All authentication state is managed through React Context
- Form validation includes both frontend and backend error handling
- The UI is fully responsive and supports dark/light themes
- Automatic logout occurs on token expiration or 401 responses